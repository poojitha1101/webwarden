---
name: Cyber Tactical Lab
colors:
  surface: '#10131a'
  surface-dim: '#10131a'
  surface-bright: '#363941'
  surface-container-lowest: '#0b0e15'
  surface-container-low: '#191b23'
  surface-container: '#1d1f27'
  surface-container-high: '#272a32'
  surface-container-highest: '#32353d'
  on-surface: '#e1e2ec'
  on-surface-variant: '#c4c9ac'
  inverse-surface: '#e1e2ec'
  inverse-on-surface: '#2d3038'
  outline: '#8e9379'
  outline-variant: '#444933'
  surface-tint: '#abd600'
  primary: '#ffffff'
  on-primary: '#283500'
  primary-container: '#c3f400'
  on-primary-container: '#556d00'
  inverse-primary: '#506600'
  secondary: '#d3fbff'
  on-secondary: '#00363a'
  secondary-container: '#00eefc'
  on-secondary-container: '#00686f'
  tertiary: '#ffffff'
  on-tertiary: '#003911'
  tertiary-container: '#6bff83'
  on-tertiary-container: '#00752a'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#c3f400'
  primary-fixed-dim: '#abd600'
  on-primary-fixed: '#161e00'
  on-primary-fixed-variant: '#3c4d00'
  secondary-fixed: '#7df4ff'
  secondary-fixed-dim: '#00dbe9'
  on-secondary-fixed: '#002022'
  on-secondary-fixed-variant: '#004f54'
  tertiary-fixed: '#6bff83'
  tertiary-fixed-dim: '#00e55b'
  on-tertiary-fixed: '#002107'
  on-tertiary-fixed-variant: '#00531b'
  background: '#10131a'
  on-background: '#e1e2ec'
  surface-variant: '#32353d'
typography:
  headline-lg:
    fontFamily: Space Grotesk
    fontSize: 36px
    fontWeight: '700'
    lineHeight: 44px
    letterSpacing: -0.02em
  headline-lg-mobile:
    fontFamily: Space Grotesk
    fontSize: 28px
    fontWeight: '700'
    lineHeight: 34px
    letterSpacing: -0.01em
  headline-md:
    fontFamily: Space Grotesk
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 30px
    letterSpacing: -0.01em
  headline-sm:
    fontFamily: Space Grotesk
    fontSize: 20px
    fontWeight: '600'
    lineHeight: 26px
    letterSpacing: 0em
  title-md:
    fontFamily: Space Grotesk
    fontSize: 16px
    fontWeight: '600'
    lineHeight: 22px
    letterSpacing: 0.02em
  body-lg:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
    letterSpacing: 0em
  body-md:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
    letterSpacing: 0.01em
  body-sm:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '400'
    lineHeight: 16px
    letterSpacing: 0.02em
  label-lg:
    fontFamily: JetBrains Mono
    fontSize: 14px
    fontWeight: '500'
    lineHeight: 18px
    letterSpacing: 0.04em
  label-md:
    fontFamily: JetBrains Mono
    fontSize: 12px
    fontWeight: '500'
    lineHeight: 16px
    letterSpacing: 0.05em
  label-sm:
    fontFamily: JetBrains Mono
    fontSize: 10px
    fontWeight: '600'
    lineHeight: 14px
    letterSpacing: 0.08em
  code-inline:
    fontFamily: JetBrains Mono
    fontSize: 13px
    fontWeight: '400'
    lineHeight: 18px
    letterSpacing: 0em
rounded:
  sm: 0.125rem
  DEFAULT: 0.25rem
  md: 0.375rem
  lg: 0.5rem
  xl: 0.75rem
  full: 9999px
spacing:
  gutter: 1rem
  gutter-sm: 0.75rem
  margin: 1rem
  margin-tablet: 1.5rem
  margin-desktop: 2.5rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2.5rem
---

## Brand & Style

This design system drives a mission-critical, interactive cybersecurity simulation environment. It equips cyber-defense operatives, threat hunters, and security engineers with a tactical command deck that transforms abstract protocol streams, penetration routines, and sandbox vulnerabilities into immediate, operational feedback.

### Aesthetic Direction: Refined Cyber Brutalism & Tactical HUD
The system balances raw cyber-brutalism with ergonomic mobile precision. Instead of chaotic retro-hacker clichés, it relies on an engineered heads-up display (HUD) philosophy:
- **Surgical Precision:** Strict geometry, 1px high-tension borders, and technical indexing tokens.
- **Instrument Density:** High-utility information density optimized for small screens, using monospaced status readouts and tabular alignment.
- **Tactical Luminescence:** Deep obsidian void canvases paired with sharp, high-lumen neon accents that function strictly as telemetry, priority indicators, and live alert telemetry.

## Colors

The palette operates in strict dark mode, establishing optical contrast between ambient void surfaces and laser-sharp chromatic indicators.

### Key Roles & Functional Rules
- **Primary (`#CCFF00` - Cyber Volt):** High-priority execution triggers, selected tab indicators, critical interactive states, and active payload targets.
- **Secondary (`#00F0FF` - Matrix Cyan):** Vector diagrams, simulated firewall topologies, telemetry graphs, and active network connections.
- **Tertiary (`#00FF66` - Terminal Green):** Successful protocol handshakes, operational nodes, secure status badges, and validated mission criteria.
- **Neutral Base (`#0A0D14` - Deep Obsidian):** Root background chassis. Structural surfaces step up to Slate Surface (`#121824`) and Elevated HUD Surface (`#182030`).
- **Alert / Hazard (`#FF2E54` - Killswitch Crimson):** Intrusion alerts, sandbox breaches, failing integrity meters, and hostile exploit signatures.

### Application Rules
- Never use full-color fills for static background cards. Backgrounds remain deep obsidian or slate; neon pigments are reserved for strokes, monospaced indicators, hairline dividers, and active interaction feedback.
- Restrict glow effects to focused actionable states (e.g., active target nodes, operational switches) to preserve visual hierarchy and screen clarity.

## Typography

The typographic hierarchy utilizes three specialized typefaces to separate narrative, telemetry, and functional action:

1. **Headlines (`Space Grotesk`):** Provides sharp, structural geometry for module headers, threat ratings, and phase markers. Rendered with tightened letter-spacing to reinforce architectural solidity.
2. **Body (`Inter`):** Drives mission briefings, scenario documentation, and incident debriefs. Provides optimal legibility against dark slate substrates without causing eye strain.
3. **Labels, Badges, and Code (`JetBrains Mono`):** Dedicated to technical data readouts, IP addresses, port identifiers, timestamp flags, and protocol codes. Uppercase tracking is applied to `label-sm` and `label-md` for an authentic tactical interface look.

## Layout & Spacing

The layout is built on an adaptive column system governed by strict telemetry grid rules.

### Layout Rhythm & Fluidity
- **Mobile (< 768px):** 4-column layout with `margin: 1rem` and `gutter-sm: 0.75rem`. Cards and console terminal outputs occupy full width to prioritize horizontal data flow.
- **Tablet (768px - 1024px):** 8-column layout with `margin-tablet: 1.5rem` and `gutter: 1rem`. Enables dual-split viewports (e.g., Target Vector Topology on the left, Attack Console on the right).
- **Desktop (> 1024px):** 12-column layout with a maximum container boundary of 1440px and `margin-desktop: 2.5rem`, delivering a command center tri-pane architecture (Lab Specs, Interactive Sandbox, Telemetry Log).

### Structural Gridlines
Backgrounds may incorporate subtle vertical and horizontal coordinate guides using 1px lines at 6% opacity of the secondary cyan (`rgba(0, 240, 255, 0.06)`), reinforcing the diagnostic display model.

## Elevation & Depth

Rather than conventional drop shadows, this design system expresses hierarchy through tonal layer stepping, technical borders, and low-opacity chromatic diffusion.

### Surface Architecture
- **Layer 0 (Canvas):** Pure `#0A0D14`. Ground-level chassis.
- **Layer 1 (Modular Panels):** `#121824` bordered by a 1px perimeter stroke of `rgba(255, 255, 255, 0.08)`.
- **Layer 2 (Overlays / Sandboxes):** `#182030` bordered by `rgba(0, 240, 255, 0.25)`.
- **Layer 3 (Modals / Floating HUD Toolbars):** `#1E273A` with a prominent 1px `#CCFF00` or `#00F0FF` highlight edge.

### Ambient Luminescence & Ghost Borders
- **Standard Cards:** Outlined with `rgba(255, 255, 255, 0.08)`. No traditional shadow.
- **Active / Target State:** Replaces standard border with `rgba(204, 255, 0, 0.8)` accompanied by an ambient glow: `0 0 16px rgba(204, 255, 0, 0.15)`.
- **Critical Breach State:** Replaces border with `rgba(255, 46, 84, 0.8)` with ambient diffusion: `0 0 16px rgba(255, 46, 84, 0.2)`.

## Shapes

The design system employs a geometric, chiseled form factor (`roundedness: 1` — base `0.25rem` / `4px`). 

- Standard components (buttons, text inputs, telemetry modules) use `4px` corner radii to avoid soft consumer-app curves.
- Larger container structures and tactical modal sheets use `rounded-lg` (`8px`).
- Specialized tactical components (such as node badges, filter tags, or terminal status dots) can feature cut-corners (chamfers) or strict 0px edges to emphasize technical brutalism.

## Components

### Buttons & Action Triggers
- **Primary Attack/Execute Button:** Filled `#CCFF00` with high-contrast `#0A0D14` bold typography (`Space Grotesk`, uppercase). Corner radius `4px`. On tap/hover, generates an outer aura of `0 0 12px rgba(204, 255, 0, 0.4)`.
- **Ghost/HUD Button:** Transparent background, 1px border of `rgba(0, 240, 255, 0.5)`, text colored `#00F0FF`. Active state fills the background with `rgba(0, 240, 255, 0.12)`.
- **Destructive/Abort Button:** Deep slate fill `#182030`, 1px border `#FF2E54`, text `#FF2E54`.

### Chips & Tactical Badges
- Constructed with `label-sm` monospaced type (`JetBrains Mono`), uppercase with leading telemetry symbol (e.g., `[● LIVE]`, `PORT: 443`, `LVL 3: ESCALATION`).
- Background: `rgba(255, 255, 255, 0.04)`. Border: 1px subtle stroke.
- Status variants map to functional colors: Tertiary (`#00FF66`) for secure/closed ports, Warning (`#FFB800`) for packet sniffing, Primary (`#CCFF00`) for targeted node, Danger (`#FF2E54`) for compromised state.

### Input Fields & Terminal Consoles
- **Terminal Inputs:** Dark slate background `#0D111A` with a 1px border of `rgba(255, 255, 255, 0.12)`. Font: `JetBrains Mono`. Prefix indicator `root@nexus:~#` rendered in `#CCFF00`.
- **Focused State:** Border transitions to `#00F0FF` with a subtle inner glow `inset 0 0 6px rgba(0, 240, 255, 0.2)`. Blinking block cursor styled in Cyber Volt (`#CCFF00`).

### Checkboxes & Toggle Radios
- Square profile with minimal 2px radius or sharp 0px radius.
- Unchecked: 1px border `rgba(255, 255, 255, 0.2)` with void background.
- Checked: Solid `#CCFF00` fill with a sharp black check glyph or inner square block.

### Cards & Module Panels
- Surface fill: `#121824`. Border: 1px solid `rgba(255, 255, 255, 0.07)`.
- Card Header: Integrated monospaced breadcrumb indicator (e.g., `// SIM_ID: NX-8849`) set in `body-sm` neutral gray.
- Optional corner brackets: 2px corner tick-marks using Primary or Secondary neon to anchor the HUD aesthetic.

### Specialized Simulation Components
- **Telemetry Health Bar:** Multi-segment progress indicator composed of discrete blocks rather than a continuous bar, colored dynamically from `#00FF66` through `#CCFF00` to `#FF2E54`.
- **Node Visualizer Tile:** Minimalist grid module containing IP metadata, ping latency in `JetBrains Mono`, and a pulse dot with CSS keyframe transmission rings.